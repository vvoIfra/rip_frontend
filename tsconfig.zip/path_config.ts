export const getBase = (): string => {
    return ""
}